package com.example.fastertyping

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.*

class AutoService : AccessibilityService() {

    companion object { var instance: AutoService? = null }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var floating: LinearLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var panel: LinearLayout
    private lateinit var wordsBox: LinearLayout
    private lateinit var autoBtn: Button
    private lateinit var delayTv: TextView
    private var running = false
    private var idx = 0

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        Toast.makeText(this, "Faster Typing ready. App se Floating Menu kholo.", Toast.LENGTH_LONG).show()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean {
        stopAuto(); hide(); instance = null
        return super.onUnbind(intent)
    }

    // ---------- Floating UI ----------
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 12f
        setOnClickListener { onClick() }
    }

    fun show() {
        if (floating != null) return
        val bubble = Button(this).apply {
            text = "⚡"; setTextColor(Color.BLACK); setPadding(0, 0, 0, 0)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#1DD3A0")) }
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }

        wordsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        autoBtn = btn("▶ Auto") { toggleAuto() }
        delayTv = TextView(this).apply { setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val minus = btn("−") { WordStore.setDelay(this, WordStore.delay(this) - 100); updateDelay() }
        val plus = btn("+") { WordStore.setDelay(this, WordStore.delay(this) + 100); updateDelay() }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply { setColor(Color.parseColor("#EE1B1F24")); cornerRadius = dp(12).toFloat() }
            addView(ScrollView(context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(180), dp(200))
                addView(wordsBox)
            })
            addView(LinearLayout(context).apply {
                orientation = LinearLayout.HORIZONTAL
                addView(minus, LinearLayout.LayoutParams(0, -2, 1f))
                addView(delayTv, LinearLayout.LayoutParams(0, -2, 2f))
                addView(plus, LinearLayout.LayoutParams(0, -2, 1f))
            })
            addView(autoBtn)
            addView(btn("📍 Set Send Position") { capturePos() })
            addView(btn("Close menu") { hide() })
        }

        floating = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(bubble); addView(panel)
        }

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(200) }

        // drag + tap on bubble
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        bubble.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { dx = ev.rawX; dy = ev.rawY; sx = lp.x; sy = lp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val mx = (ev.rawX - dx).toInt(); val my = (ev.rawY - dy).toInt()
                    if (Math.abs(mx) > 10 || Math.abs(my) > 10) moved = true
                    lp.x = sx + mx; lp.y = sy + my
                    wm.updateViewLayout(floating, lp)
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(floating, lp)
        updateDelay()
    }

    fun hide() {
        stopAuto()
        floating?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        floating = null
    }

    private fun togglePanel() {
        if (panel.visibility == View.VISIBLE) panel.visibility = View.GONE
        else { refreshWords(); panel.visibility = View.VISIBLE }
    }

    private fun refreshWords() {
        wordsBox.removeAllViews()
        WordStore.words(this).forEach { w -> wordsBox.addView(btn(w) { sendText(w) }) }
    }

    private fun updateDelay() { delayTv.text = "${WordStore.delay(this)} ms" }

    // ---------- Set send position ----------
    private fun capturePos() {
        val overlay = FrameLayout(this).apply {
            setBackgroundColor(Color.parseColor("#55000000"))
            addView(TextView(context).apply {
                text = "Chat ke SEND button par tap karo"
                setTextColor(Color.WHITE); textSize = 18f
            }, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        }
        val p = WindowManager.LayoutParams(
            -1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        overlay.setOnTouchListener { _, ev ->
            if (ev.action == MotionEvent.ACTION_UP) {
                WordStore.savePos(this, ev.rawX, ev.rawY)
                wm.removeView(overlay)
                Toast.makeText(this, "Send position saved ✓", Toast.LENGTH_SHORT).show()
            }
            true
        }
        wm.addView(overlay, p)
    }

    // ---------- Typing + sending ----------
    private fun sendText(t: String): Boolean {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) {
            Toast.makeText(this, "Pehle chat box par tap karo", Toast.LENGTH_SHORT).show()
            return false
        }
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        handler.postDelayed({ pressSend(node) }, 120)
        return true
    }

    private fun pressSend(node: AccessibilityNodeInfo) {
        val x = WordStore.sendX(this); val y = WordStore.sendY(this)
        if (x >= 0) tap(x, y)
        else if (Build.VERSION.SDK_INT >= 30)
            node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 50)).build()
        dispatchGesture(g, null, null)
    }

    // ---------- Auto mode ----------
    private val loop = object : Runnable {
        override fun run() {
            if (!running) return
            val list = WordStore.words(this@AutoService)
            if (list.isEmpty() || !sendText(list[idx % list.size])) { stopAuto(); return }
            idx++
            handler.postDelayed(this, WordStore.delay(this@AutoService).toLong())
        }
    }

    private fun toggleAuto() { if (running) stopAuto() else startAuto() }
    private fun startAuto() { running = true; idx = 0; autoBtn.text = "■ Stop"; handler.post(loop) }
    private fun stopAuto() {
        running = false; handler.removeCallbacks(loop)
        if (::autoBtn.isInitialized) autoBtn.text = "▶ Auto"
    }
}
