# Faster Typing (apna version)

Android app: custom keyboard + floating ⚡ menu + saved words + auto send (delay based).

## Features
- Custom keyboard (QWERTY + numbers)
- Floating draggable menu (Accessibility overlay, extra overlay permission nahi chahiye)
- Words list: app me edit karo, har line = ek message
- Tap par word chat box me likhta hai aur "Send Position" par tap karta hai
- Auto mode: words ek ke baad ek, delay (ms) ke saath

## APK kaise banao (GitHub par)
1. Is poore folder ko apni GitHub repo me upload/push karo.
2. Repo > **Actions** tab > **Build APK** > run hone do (~3-5 min).
3. Run khulo > neeche **Artifacts** > `FasterTyping-debug-apk` download karo, unzip karo, APK install karo.

## Phone me setup
1. App kholo > Enable Keyboard > Choose Keyboard
2. Enable Accessibility > "Faster Typing Floating Menu" ON
3. Open Floating Menu
4. Chat box par tap karo, ⚡ dabao, "Set Send Position" se send button par tap karke position save karo
5. Word par tap karo ya Auto start karo
