package com.example.fastertyping

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0F1317"))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        fun title(t: String, size: Float, color: String) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.parseColor(color))
            setPadding(0, dp(10), 0, dp(6))
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false
            setOnClickListener { onClick() }
        }

        root.addView(title("FASTER TYPING", 22f, "#FFFFFF"))
        root.addView(title("01 • QUICK SETUP", 12f, "#1DD3A0"))
        root.addView(btn("Enable Keyboard") { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) })
        root.addView(btn("Choose Keyboard") {
            (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker()
        })
        root.addView(btn("Enable Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })

        root.addView(title("02 • PREMIUM TOOLS", 12f, "#1DD3A0"))
        root.addView(btn("Open Floating Menu") {
            val s = AutoService.instance
            if (s == null) Toast.makeText(this, "Pehle Accessibility enable karo", Toast.LENGTH_LONG).show()
            else s.show()
        })
        root.addView(btn("Close Floating Menu") { AutoService.instance?.hide() })

        root.addView(title("03 • AUTO WORDS LIST (har line = ek message)", 12f, "#1DD3A0"))
        val et = EditText(this).apply {
            setText(WordStore.rawWords(this@MainActivity))
            setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#1B1F24"))
            minLines = 5; gravity = Gravity.TOP; setPadding(dp(10), dp(10), dp(10), dp(10))
        }
        root.addView(et)
        root.addView(btn("Save Words") {
            WordStore.saveWords(this, et.text.toString())
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
