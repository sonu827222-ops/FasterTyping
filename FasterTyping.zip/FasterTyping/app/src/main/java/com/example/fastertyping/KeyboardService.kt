package com.example.fastertyping

import android.graphics.Color
import android.inputmethodservice.InputMethodService
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class KeyboardService : InputMethodService() {
    private var shift = false
    private var numbers = false
    private lateinit var root: LinearLayout

    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#1B1F24"))
            setPadding(dp(3), dp(6), dp(3), dp(6))
        }
        build()
        return root
    }

    private fun key(label: String, weight: Float = 1f, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 16f
        setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#2C333B"))
        setPadding(0, 0, 0, 0)
        layoutParams = LinearLayout.LayoutParams(0, dp(46), weight).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }
        setOnClickListener { onClick() }
    }

    private fun charKey(c: Char) = key(if (shift) c.uppercase() else c.toString()) {
        currentInputConnection?.commitText(if (shift) c.uppercase() else c.toString(), 1)
        if (shift) { shift = false; build() }
    }

    private fun row(vararg v: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEach { addView(it) }
    }

    private fun build() {
        root.removeAllViews()
        val rows = if (numbers) listOf("1234567890", "-/:;()$&@\"", ".,?!'")
                   else listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

        root.addView(row(*rows[0].map { charKey(it) }.toTypedArray()))
        root.addView(row(*rows[1].map { charKey(it) }.toTypedArray()))

        val third = mutableListOf<View>()
        if (!numbers) third.add(key(if (shift) "⇧" else "⇪", 1.5f) { shift = !shift; build() })
        rows[2].forEach { third.add(charKey(it)) }
        third.add(key("⌫", 1.5f) { currentInputConnection?.deleteSurroundingText(1, 0) })
        root.addView(row(*third.toTypedArray()))

        root.addView(row(
            key(if (numbers) "abc" else "123", 1.5f) { numbers = !numbers; build() },
            key(",") { currentInputConnection?.commitText(",", 1) },
            key("space", 5f) { currentInputConnection?.commitText(" ", 1) },
            key(".") { currentInputConnection?.commitText(".", 1) },
            key("↵", 1.5f) { enter() }
        ))
    }

    private fun enter() {
        val ic = currentInputConnection ?: return
        val action = (currentInputEditorInfo?.imeOptions ?: 0) and EditorInfo.IME_MASK_ACTION
        if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
            ic.performEditorAction(action)
        } else {
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
            ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
        }
    }
}
