package com.example.fastertyping

import android.content.Context

fun Context.dp(n: Int) = (n * resources.displayMetrics.density).toInt()

object WordStore {
    private fun p(c: Context) = c.getSharedPreferences("ft", Context.MODE_PRIVATE)

    fun words(c: Context): List<String> =
        p(c).getString("words", "Hello\nWelcome\nThanks")!!
            .split("\n").map { it.trim() }.filter { it.isNotEmpty() }

    fun saveWords(c: Context, raw: String) = p(c).edit().putString("words", raw).apply()
    fun rawWords(c: Context) = p(c).getString("words", "Hello\nWelcome\nThanks")!!

    fun delay(c: Context) = p(c).getInt("delay", 1000)
    fun setDelay(c: Context, ms: Int) = p(c).edit().putInt("delay", ms.coerceAtLeast(300)).apply()

    fun sendX(c: Context) = p(c).getFloat("sx", -1f)
    fun sendY(c: Context) = p(c).getFloat("sy", -1f)
    fun savePos(c: Context, x: Float, y: Float) = p(c).edit().putFloat("sx", x).putFloat("sy", y).apply()
}
